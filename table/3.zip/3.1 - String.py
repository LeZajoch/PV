# 1
a = "Hel", "aasda", "BAF"
print(a)

# 2
aa = 1, 5, 3, 8, 2
print(aa)
# 3
ab = "koukej na to"
test = ab[1]
print(test)
# 4
st = "ahoj", "ahoj", "ahoj", "aaa"
print(st)

# 5
sett = None, "aaa"
print(sett)

# 6
ah = "ahoooj"
pr = "vitej !!"
print("cus,", ah, "ahh", pr)

# 7 - nejde

# 8
str1 = "bafiky baf"
poc = len(str1)
print(poc)

# 9
str2 = "Akomasotore"
nstr2 = "ahooojky " + str2
print(nstr2)

# 10 a 11
str3 = "miluju tofiffe hahah"
nstr3 = str3.replace("miluj", "A ja miluj") #11
nstr3a = str3.replace("hahah", "") #10
print(nstr3 + nstr3a)

# 12
str4 = "muj novy kamos string"
if "novy" in str4:
    print("je tu")
else:
    print("zase tu neni..")

# 13
str5 = "sude nas, jenz si na nebesich, pomahej a chran me pri programovani, AMEN"
tstr5 = str5[2]
print(tstr5)